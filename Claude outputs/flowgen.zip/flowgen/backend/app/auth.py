"""Entra ID のアクセストークン検証。AUTH_ENABLED=false のときは匿名ユーザー扱い。"""
from __future__ import annotations

from functools import lru_cache

from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from .config import settings

_bearer = HTTPBearer(auto_error=False)


@lru_cache
def _jwks():
    import jwt

    return jwt.PyJWKClient(
        f"https://login.microsoftonline.com/{settings.tenant_id}/discovery/v2.0/keys"
    )


def current_user(cred: HTTPAuthorizationCredentials | None = Depends(_bearer)) -> str:
    if not settings.auth_enabled:
        return "local-user"
    if not cred:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "認証が必要です")
    import jwt

    try:
        key = _jwks().get_signing_key_from_jwt(cred.credentials).key
        claims = jwt.decode(
            cred.credentials,
            key,
            algorithms=["RS256"],
            audience=[settings.api_client_id, f"api://{settings.api_client_id}"],
            issuer=f"https://login.microsoftonline.com/{settings.tenant_id}/v2.0",
        )
    except Exception as e:  # noqa: BLE001
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, f"トークンが無効です: {e}") from e
    if "access_as_user" not in claims.get("scp", "").split():
        raise HTTPException(status.HTTP_403_FORBIDDEN, "スコープ access_as_user が必要です")
    return claims.get("oid") or claims["sub"]
