import os

from dotenv import load_dotenv

load_dotenv()


def _bool(name: str, default: bool = False) -> bool:
    return os.getenv(name, str(default)).lower() in ("1", "true", "yes")


class Settings:
    # Azure OpenAI
    aoai_endpoint = os.getenv("AZURE_OPENAI_ENDPOINT", "")
    aoai_api_key = os.getenv("AZURE_OPENAI_API_KEY", "")  # 空ならマネージドIDで認証
    aoai_deployment = os.getenv("AZURE_OPENAI_DEPLOYMENT", "gpt-4o")
    aoai_api_version = os.getenv("AZURE_OPENAI_API_VERSION", "2024-10-21")

    # Claude（Anthropic直 / Microsoft Foundry）
    anthropic_api_key = os.getenv("ANTHROPIC_API_KEY", "")
    claude_model = os.getenv("CLAUDE_MODEL", "claude-sonnet-5-5")  # Foundryではデプロイ名
    foundry_resource = os.getenv("ANTHROPIC_FOUNDRY_RESOURCE", "")
    foundry_api_key = os.getenv("ANTHROPIC_FOUNDRY_API_KEY", "")  # 空ならEntra ID

    # LLM_PROVIDER: azure_openai / claude / foundry / mock（未指定なら設定値から自動判定）
    llm_provider = os.getenv("LLM_PROVIDER") or (
        "mock" if _bool("MOCK_LLM")
        else "azure_openai" if os.getenv("AZURE_OPENAI_ENDPOINT")
        else "foundry" if os.getenv("ANTHROPIC_FOUNDRY_RESOURCE")
        else "claude" if os.getenv("ANTHROPIC_API_KEY")
        else "mock"
    )
    mock_llm = llm_provider == "mock"

    # Cosmos DB（未設定ならローカルJSONに保存）
    cosmos_endpoint = os.getenv("COSMOS_ENDPOINT", "")
    cosmos_key = os.getenv("COSMOS_KEY", "")  # 空ならマネージドID
    cosmos_database = os.getenv("COSMOS_DATABASE", "flowgen")
    cosmos_container = os.getenv("COSMOS_CONTAINER", "projects")
    local_data_dir = os.getenv("LOCAL_DATA_DIR", "./data")

    # Entra ID 認証
    auth_enabled = _bool("AUTH_ENABLED", False)
    tenant_id = os.getenv("ENTRA_TENANT_ID", "")
    api_client_id = os.getenv("ENTRA_API_CLIENT_ID", "")  # API側アプリ登録のクライアントID

    cors_origins = [o for o in os.getenv("CORS_ORIGINS", "http://localhost:5173").split(",") if o]


settings = Settings()
