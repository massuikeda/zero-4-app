"""固定テンプレートによる描画。AIの出力（JSON）から毎回同じ型の図を生成する。"""
from __future__ import annotations

from xml.sax.saxutils import escape

from .schemas import Comparison, Flow

# ステップ種別 → Mermaid図形
_MERMAID_SHAPE = {
    "作業": ('["', '"]'),
    "判断": ('{"', '"}'),
    "システム処理": ('[["', '"]]'),
    "帳票": ('[/"', '"/]'),
    "待ち": ('(["', '"])'),
}

# 変更区分 → 色（Mermaid / draw.io 共通）
CHANGE_COLORS = {
    "排除": "#9E9E9E",
    "統合": "#7B1FA2",
    "入替": "#F57C00",
    "簡素化": "#0288D1",
    "自動化": "#2E7D32",
    "新規": "#C2185B",
}
_CHANGE_CLASS = {"排除": "c_del", "統合": "c_mrg", "入替": "c_ord", "簡素化": "c_smp", "自動化": "c_auto", "新規": "c_new"}


def _m(text: str) -> str:
    return text.replace('"', "#quot;").replace("\n", " ")


def to_mermaid(flow: Flow) -> str:
    lines = ["flowchart LR"]
    used = {s.lane for s in flow.steps}
    for li, lane in enumerate(flow.lanes):
        if lane not in used:
            continue  # ステップのないレーンは描かない
        lines.append(f'  subgraph L{li}["{_m(lane)}"]')
        lines.append("    direction TB")
        for s in flow.steps:
            if s.lane != lane:
                continue
            o, c = _MERMAID_SHAPE.get(s.type, _MERMAID_SHAPE["作業"])
            label = f"{s.id} {s.name}"
            if s.minutes:
                label += f"<br/><small>{s.minutes}分</small>"
            if s.change:
                label = f"【{s.change}】" + label
            lines.append(f"    {s.id}{o}{_m(label)}{c}")
        lines.append("  end")
    # レーン外（lanes にないlane名）
    orphan = [s for s in flow.steps if s.lane not in flow.lanes]
    for s in orphan:
        o, c = _MERMAID_SHAPE.get(s.type, _MERMAID_SHAPE["作業"])
        lines.append(f"  {s.id}{o}{_m(s.id + ' ' + s.name)}{c}")
    ids = {s.id for s in flow.steps}
    for s in flow.steps:
        for i, n in enumerate(s.next):
            if n not in ids:
                continue
            label = s.condition_labels[i] if i < len(s.condition_labels) else ""
            arrow = f' -->|"{_m(label)}"| ' if label else " --> "
            lines.append(f"  {s.id}{arrow}{n}")
    lines.append("  classDef issue stroke:#D32F2F,stroke-width:3px,fill:#FFEBEE,color:#000")
    for action, cls in _CHANGE_CLASS.items():
        col = CHANGE_COLORS[action]
        lines.append(f"  classDef {cls} stroke:{col},stroke-width:3px,fill:{col}22,color:#000")
    for s in flow.steps:
        if s.change:
            lines.append(f"  class {s.id} {_CHANGE_CLASS[s.change]}")
        elif s.issue:
            lines.append(f"  class {s.id} issue")
    return "\n".join(lines)


# ---------- draw.io（diagrams.net）----------
_DRAWIO_STYLE = {
    "作業": "rounded=1;whiteSpace=wrap;html=1;",
    "判断": "rhombus;whiteSpace=wrap;html=1;",
    "システム処理": "shape=process;whiteSpace=wrap;html=1;backgroundOutline=1;",
    "帳票": "shape=document;whiteSpace=wrap;html=1;boundedLbl=1;",
    "待ち": "shape=delay;whiteSpace=wrap;html=1;",
}
LANE_H, LANE_HEADER, COL_W, NODE_W, NODE_H = 140, 40, 180, 140, 70


def to_drawio(flow: Flow, title: str = "業務フロー") -> str:
    cells = ['<mxCell id="0"/>', '<mxCell id="1" parent="0"/>']
    lanes = list(flow.lanes) + [s.lane for s in flow.steps if s.lane not in flow.lanes]
    lanes = list(dict.fromkeys(lanes))
    width = LANE_HEADER + COL_W * max(len(flow.steps), 1) + 40
    for li, lane in enumerate(lanes):
        cells.append(
            f'<mxCell id="lane{li}" value="{escape(lane)}" '
            f'style="swimlane;horizontal=0;startSize={LANE_HEADER};html=1;fillColor=#F5F5F5;" '
            f'vertex="1" parent="1"><mxGeometry x="0" y="{li * LANE_H}" width="{width}" height="{LANE_H}" as="geometry"/></mxCell>'
        )
    for col, s in enumerate(flow.steps):
        li = lanes.index(s.lane)
        style = _DRAWIO_STYLE.get(s.type, _DRAWIO_STYLE["作業"])
        if s.change:
            col_hex = CHANGE_COLORS[s.change]
            style += f"strokeColor={col_hex};strokeWidth=3;fillColor={col_hex}22;"
        elif s.issue:
            style += "strokeColor=#D32F2F;strokeWidth=3;fillColor=#FFEBEE;"
        label = f"{s.id} {s.name}"
        if s.change:
            label = f"【{s.change}】<br>" + label
        if s.minutes:
            label += f"<br><font style='font-size:10px'>{s.minutes}分</font>"
        tooltip = f' tooltip="{escape(s.issue, {chr(34): "&quot;"})}"' if s.issue else ""
        x = LANE_HEADER + 20 + col * COL_W
        y = (LANE_H - NODE_H) // 2
        cells.append(
            f'<UserObject id="{s.id}" label="{escape(label, {chr(34): "&quot;"})}"{tooltip}>'
            f'<mxCell style="{style}" vertex="1" parent="lane{li}">'
            f'<mxGeometry x="{x}" y="{y}" width="{NODE_W}" height="{NODE_H}" as="geometry"/></mxCell></UserObject>'
        )
    ids = {s.id for s in flow.steps}
    e = 0
    for s in flow.steps:
        for i, n in enumerate(s.next):
            if n not in ids:
                continue
            label = s.condition_labels[i] if i < len(s.condition_labels) else ""
            e += 1
            cells.append(
                f'<mxCell id="e{e}" value="{escape(label)}" '
                f'style="edgeStyle=orthogonalEdgeStyle;rounded=0;html=1;endArrow=block;" '
                f'edge="1" parent="1" source="{s.id}" target="{n}"><mxGeometry relative="1" as="geometry"/></mxCell>'
            )
    body = "".join(cells)
    return (
        f'<mxfile host="flowgen"><diagram name="{escape(title)}">'
        f'<mxGraphModel dx="1200" dy="800" grid="1" gridSize="10" page="1" pageWidth="1600" pageHeight="900">'
        f"<root>{body}</root></mxGraphModel></diagram></mxfile>"
    )


# ---------- 比較 ----------
def _handoffs(flow: Flow) -> int:
    lane = {s.id: s.lane for s in flow.steps}
    return sum(1 for s in flow.steps for n in s.next if n in lane and lane[n] != s.lane)


def compare(asis: Flow, tobe: Flow) -> Comparison:
    am = sum(s.minutes for s in asis.steps)
    tm = sum(s.minutes for s in tobe.steps)
    return Comparison(
        asis_steps=len(asis.steps),
        tobe_steps=len(tobe.steps),
        asis_minutes=am,
        tobe_minutes=tm,
        asis_handoffs=_handoffs(asis),
        tobe_handoffs=_handoffs(tobe),
        asis_issues=sum(1 for s in asis.steps if s.issue),
        reduction_rate=round((am - tm) / am * 100, 1) if am else 0.0,
    )
