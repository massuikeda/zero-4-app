"""業務フローの「固定の型」を定義するスキーマ。

Azure OpenAI の Structured Outputs にこのモデルを渡すことで、
AIの出力が必ずこの形式になる（＝毎回同じ型のフローが出る）。
"""
from __future__ import annotations

from typing import Literal, Optional

from pydantic import BaseModel, Field

# ステップ種別（図形が固定で対応する）
StepType = Literal["作業", "判断", "システム処理", "帳票", "待ち"]

# TO-BE の変更区分（ECRS + 自動化 + 新規）
ChangeAction = Literal["排除", "統合", "入替", "簡素化", "自動化", "新規"]


# ---------- 入力 ----------
class FlowInput(BaseModel):
    business_name: str = Field(..., description="業務名")
    department: str = Field("", description="対象部署")
    frequency: str = Field("", description="実施頻度（例：月20回）")
    actors: list[str] = Field(default_factory=list, description="登場人物・部署（スイムレーン）")
    current_steps: str = Field(..., description="現状手順（自由記述・箇条書き）")
    tools: str = Field("", description="使用ツール・システム")
    issues: str = Field("", description="現状の課題")
    goals: str = Field("", description="改善の目標")
    constraints: str = Field("", description="制約（予算・使えるシステム等）")


# ---------- フロー本体 ----------
class Step(BaseModel):
    id: str = Field(..., description="ステップID。S01, S02... の連番")
    lane: str = Field(..., description="担当スイムレーン。lanes のいずれか")
    type: StepType
    name: str = Field(..., description="ステップ名（20文字以内の動詞句）")
    tool: str = Field(..., description="使用ツール。なければ空文字")
    minutes: int = Field(..., description="1回あたりの所要時間（分）。不明なら推定値")
    issue: Optional[str] = Field(..., description="このステップの課題。なければ null")
    change: Optional[ChangeAction] = Field(..., description="TO-BEでの変更区分。AS-ISでは null")
    next: list[str] = Field(..., description="次のステップIDのリスト。終了なら空配列")
    condition_labels: list[str] = Field(
        ..., description="判断ステップの分岐ラベル（next と同じ順）。判断以外は空配列"
    )


class Flow(BaseModel):
    lanes: list[str]
    steps: list[Step]


class Change(BaseModel):
    target_step_ids: list[str] = Field(..., description="対象となるAS-ISのステップID")
    action: ChangeAction
    title: str = Field(..., description="施策名")
    description: str
    reason: str
    effect_minutes: int = Field(..., description="1回あたりの削減分数（削減はマイナス）")
    difficulty: Literal["低", "中", "高"]
    priority: Literal["高", "中", "低"]


class AsIsResult(BaseModel):
    flow: Flow
    summary: str = Field(..., description="現状業務の要約（3文以内）")


class ToBeResult(BaseModel):
    flow: Flow
    changes: list[Change]
    summary: str = Field(..., description="改善方針の要約（3文以内）")


# ---------- API ----------
class ToBeRequest(BaseModel):
    input: FlowInput
    asis: Flow


class Comparison(BaseModel):
    asis_steps: int
    tobe_steps: int
    asis_minutes: int
    tobe_minutes: int
    asis_handoffs: int
    tobe_handoffs: int
    asis_issues: int
    reduction_rate: float


class Project(BaseModel):
    id: str
    owner: str = ""
    created_at: str
    updated_at: str
    input: FlowInput
    asis: Optional[AsIsResult] = None
    tobe: Optional[ToBeResult] = None


class RenderRequest(BaseModel):
    flow: Flow
    title: str = "業務フロー"
