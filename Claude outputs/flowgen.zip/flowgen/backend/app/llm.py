"""LLM 呼び出し。どのプロバイダでも「固定スキーマのJSON」を強制して返す。

LLM_PROVIDER で切り替え:
  azure_openai … Azure OpenAI（本番想定）
  claude       … Claude API（Anthropic直。Azure OpenAI がない間の代替・検証用）
  foundry      … Microsoft Foundry 上の Claude（Azure契約・Azure内で完結させたい場合）
  mock         … LLMなし（画面確認用）
"""
from __future__ import annotations

from functools import lru_cache

from .config import settings
from .prompts import ASIS_SYSTEM, TOBE_SYSTEM, asis_user_prompt, tobe_user_prompt
from .schemas import AsIsResult, Flow, FlowInput, ToBeResult
from . import mock


# ---------- Azure OpenAI ----------
@lru_cache
def _aoai_client():
    from openai import AzureOpenAI

    if settings.aoai_api_key:
        return AzureOpenAI(
            azure_endpoint=settings.aoai_endpoint,
            api_key=settings.aoai_api_key,
            api_version=settings.aoai_api_version,
        )
    # キーなし → マネージドID / az login の資格情報で認証（本番推奨）
    from azure.identity import DefaultAzureCredential, get_bearer_token_provider

    token_provider = get_bearer_token_provider(
        DefaultAzureCredential(), "https://cognitiveservices.azure.com/.default"
    )
    return AzureOpenAI(
        azure_endpoint=settings.aoai_endpoint,
        azure_ad_token_provider=token_provider,
        api_version=settings.aoai_api_version,
    )


def _aoai_parse(system: str, user: str, model_cls):
    completion = _aoai_client().beta.chat.completions.parse(
        model=settings.aoai_deployment,
        messages=[{"role": "system", "content": system}, {"role": "user", "content": user}],
        response_format=model_cls,
        temperature=0.2,
    )
    msg = completion.choices[0].message
    if msg.refusal:
        raise RuntimeError(f"モデルが応答を拒否しました: {msg.refusal}")
    return msg.parsed


# ---------- Claude（Anthropic直 / Microsoft Foundry）----------
@lru_cache
def _claude_client():
    if settings.llm_provider == "foundry":
        from anthropic import AnthropicFoundry

        if settings.foundry_api_key:
            return AnthropicFoundry(api_key=settings.foundry_api_key, resource=settings.foundry_resource)
        from azure.identity import DefaultAzureCredential, get_bearer_token_provider

        token_provider = get_bearer_token_provider(DefaultAzureCredential(), "https://ai.azure.com/.default")
        return AnthropicFoundry(resource=settings.foundry_resource, azure_ad_token_provider=token_provider)

    from anthropic import Anthropic

    return Anthropic(api_key=settings.anthropic_api_key or None)


def _claude_parse(system: str, user: str, model_cls):
    res = _claude_client().messages.parse(
        model=settings.claude_model,
        max_tokens=8000,
        system=system,
        messages=[{"role": "user", "content": user}],
        output_format=model_cls,  # Structured Outputs：スキーマ通りのJSONを強制
    )
    if res.stop_reason == "refusal":
        raise RuntimeError("モデルが応答を拒否しました")
    if res.stop_reason == "max_tokens":
        raise RuntimeError("出力が長すぎて途中で切れました（ステップ数を減らしてください）")
    return res.parsed_output


# ---------- 共通入口 ----------
def _parse(system: str, user: str, model_cls):
    if settings.llm_provider in ("claude", "foundry"):
        return _claude_parse(system, user, model_cls)
    return _aoai_parse(system, user, model_cls)


def generate_asis(inp: FlowInput) -> AsIsResult:
    if settings.llm_provider == "mock":
        return mock.generate_asis(inp)
    return _parse(ASIS_SYSTEM, asis_user_prompt(inp), AsIsResult)


def generate_tobe(inp: FlowInput, asis: Flow) -> ToBeResult:
    if settings.llm_provider == "mock":
        return mock.generate_tobe(inp, asis)
    return _parse(TOBE_SYSTEM, tobe_user_prompt(inp, asis.model_dump_json(indent=1)), ToBeResult)


def model_label() -> str:
    return {
        "azure_openai": f"Azure OpenAI: {settings.aoai_deployment}",
        "claude": f"Claude API: {settings.claude_model}",
        "foundry": f"Foundry Claude: {settings.claude_model}",
    }.get(settings.llm_provider, "モック")
