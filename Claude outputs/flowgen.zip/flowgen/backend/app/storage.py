"""履歴保存。COSMOS_ENDPOINT があれば Cosmos DB、なければローカルJSON。"""
from __future__ import annotations

import json
from pathlib import Path

from .config import settings
from .schemas import Project


class LocalStore:
    def __init__(self, root: str):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)

    def save(self, p: Project) -> Project:
        (self.root / f"{p.id}.json").write_text(p.model_dump_json(indent=1), encoding="utf-8")
        return p

    def get(self, pid: str, owner: str) -> Project | None:
        f = self.root / f"{Path(pid).name}.json"
        if not f.exists():
            return None
        p = Project.model_validate_json(f.read_text(encoding="utf-8"))
        return p if (not owner or p.owner == owner) else None

    def list(self, owner: str) -> list[Project]:
        items = [Project.model_validate_json(f.read_text(encoding="utf-8")) for f in self.root.glob("*.json")]
        items = [p for p in items if not owner or p.owner == owner]
        return sorted(items, key=lambda p: p.updated_at, reverse=True)

    def delete(self, pid: str, owner: str) -> bool:
        p = self.get(pid, owner)
        if not p:
            return False
        (self.root / f"{p.id}.json").unlink()
        return True


class CosmosStore:
    """パーティションキー: /owner（ユーザー単位で履歴を分離）"""

    def __init__(self):
        from azure.cosmos import CosmosClient, PartitionKey

        if settings.cosmos_key:
            client = CosmosClient(settings.cosmos_endpoint, credential=settings.cosmos_key)
            db = client.create_database_if_not_exists(settings.cosmos_database)
            self.c = db.create_container_if_not_exists(
                id=settings.cosmos_container, partition_key=PartitionKey(path="/owner")
            )
        else:
            # マネージドID（データプレーンRBAC）ではDB/コンテナを作れないため事前作成が前提
            from azure.identity import DefaultAzureCredential

            client = CosmosClient(settings.cosmos_endpoint, credential=DefaultAzureCredential())
            self.c = client.get_database_client(settings.cosmos_database).get_container_client(
                settings.cosmos_container
            )

    def save(self, p: Project) -> Project:
        self.c.upsert_item(json.loads(p.model_dump_json()))
        return p

    def get(self, pid: str, owner: str) -> Project | None:
        from azure.cosmos.exceptions import CosmosResourceNotFoundError

        try:
            return Project.model_validate(self.c.read_item(pid, partition_key=owner))
        except CosmosResourceNotFoundError:
            return None

    def list(self, owner: str) -> list[Project]:
        q = "SELECT * FROM c WHERE c.owner = @o ORDER BY c.updated_at DESC"
        rows = self.c.query_items(q, parameters=[{"name": "@o", "value": owner}], partition_key=owner)
        return [Project.model_validate(r) for r in rows]

    def delete(self, pid: str, owner: str) -> bool:
        if not self.get(pid, owner):
            return False
        self.c.delete_item(pid, partition_key=owner)
        return True


store = CosmosStore() if settings.cosmos_endpoint else LocalStore(settings.local_data_dir)
