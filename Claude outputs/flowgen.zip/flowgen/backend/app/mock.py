"""Azure OpenAI 未接続時のモック。入力の手順行からそれらしいフローを機械的に作る。"""
from __future__ import annotations

import re

from .schemas import AsIsResult, Change, Flow, FlowInput, Step, ToBeResult

_DECISION = ("承認", "確認", "チェック", "判断", "審査")
_DOC = ("Excel", "エクセル", "紙", "PDF", "帳票", "印刷", "書類")
_WAIT = ("待ち", "待つ")
_ISSUE_HINT = ("転記", "手入力", "二重", "印刷", "紙", "メール", "Excel", "待ち")


def _lines(text: str) -> list[str]:
    out = []
    for ln in text.splitlines():
        ln = re.sub(r"^\s*([-・*●]|\d+[.)．、])\s*", "", ln).strip()
        if ln:
            out.append(ln)
    return out


def _type_of(line: str) -> str:
    if any(k in line for k in _WAIT):
        return "待ち"
    if any(k in line for k in _DECISION):
        return "判断"
    if any(k in line for k in _DOC):
        return "帳票"
    if "システム" in line or "登録" in line:
        return "システム処理"
    return "作業"


def generate_asis(inp: FlowInput) -> AsIsResult:
    lanes = list(inp.actors) or ["担当者"]
    lines = _lines(inp.current_steps) or ["業務を実施する"]
    steps: list[Step] = []
    current_lane = lanes[0]
    for i, line in enumerate(lines[:20]):
        for lane in lanes:
            if line.startswith(lane) or f"{lane}が" in line or f"{lane}は" in line:
                current_lane = lane
                break
        t = _type_of(line)
        sid = f"S{i + 1:02d}"
        nxt = [f"S{i + 2:02d}"] if i + 1 < len(lines) else []
        labels: list[str] = []
        if t == "判断" and i > 0 and nxt:
            nxt = nxt + [f"S{i:02d}"]
            labels = ["OK", "差戻し"]
        elif t == "判断":
            t = "作業"
        issue = None
        hit = [k for k in _ISSUE_HINT if k in line]
        if hit:
            issue = f"「{hit[0]}」による手作業・待ちが発生"
        steps.append(
            Step(
                id=sid, lane=current_lane, type=t, name=line[:24], tool="",
                minutes=10 if t != "待ち" else 60, issue=issue, change=None,
                next=nxt, condition_labels=labels,
            )
        )
    return AsIsResult(
        flow=Flow(lanes=lanes, steps=steps),
        summary=f"（モック）{inp.business_name}の現状業務を{len(steps)}ステップに整理しました。",
    )


def generate_tobe(inp: FlowInput, asis: Flow) -> ToBeResult:
    lanes = list(asis.lanes)
    if "システム" not in lanes:
        lanes.append("システム")
    changes: list[Change] = []
    kept: list[Step] = []
    for s in asis.steps:
        if s.type == "待ち":
            changes.append(Change(
                target_step_ids=[s.id], action="排除", title=f"{s.name}の解消",
                description="ワークフローの通知で待ち時間を削減", reason="待ちが付加価値を生まないため",
                effect_minutes=-s.minutes, difficulty="中", priority="高",
            ))
            continue
        if s.issue:
            changes.append(Change(
                target_step_ids=[s.id], action="自動化", title=f"{s.name}のシステム化",
                description="入力フォームとシステム連携で手作業をなくす", reason=s.issue,
                effect_minutes=-(s.minutes // 2), difficulty="中", priority="中",
            ))
            kept.append(s.model_copy(update={
                "lane": "システム", "type": "システム処理", "minutes": s.minutes - s.minutes // 2,
                "change": "自動化", "issue": None,
            }))
        else:
            kept.append(s.model_copy())
    # 連番振り直し・遷移を直列に再構成
    idmap = {s.id: f"S{i + 1:02d}" for i, s in enumerate(kept)}
    tobe_steps = []
    for i, s in enumerate(kept):
        nxt = [f"S{i + 2:02d}"] if i + 1 < len(kept) else []
        labels: list[str] = []
        if s.type == "判断" and nxt:
            back = [idmap[n] for n in s.next if n in idmap and idmap[n] != nxt[0]]
            if back:
                nxt += back[:1]
                labels = ["OK", "差戻し"]
            else:
                s = s.model_copy(update={"type": "作業"})
        tobe_steps.append(s.model_copy(update={"id": idmap[s.id], "next": nxt, "condition_labels": labels}))
    return ToBeResult(
        flow=Flow(lanes=lanes, steps=tobe_steps),
        changes=changes,
        summary="（モック）待ちの排除と、課題のあるステップのシステム化を中心に改善しました。",
    )
