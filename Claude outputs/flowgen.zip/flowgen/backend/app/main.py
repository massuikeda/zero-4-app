from __future__ import annotations

import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from fastapi import Depends, FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from . import llm, render
from .auth import current_user
from .config import settings
from .schemas import AsIsResult, Flow, FlowInput, Project, RenderRequest, ToBeRequest, ToBeResult
from .storage import store

app = FastAPI(title="FlowGen - 業務フロー自動作成", version="0.1.0")
app.add_middleware(
    CORSMiddleware, allow_origins=settings.cors_origins, allow_methods=["*"], allow_headers=["*"]
)


class AsIsResponse(BaseModel):
    result: AsIsResult
    mermaid: str


class ToBeResponse(BaseModel):
    result: ToBeResult
    mermaid: str
    comparison: render.Comparison


class SaveRequest(BaseModel):
    id: Optional[str] = None
    input: FlowInput
    asis: Optional[AsIsResult] = None
    tobe: Optional[ToBeResult] = None


def _validate_flow(flow: Flow) -> None:
    ids = [s.id for s in flow.steps]
    if len(ids) != len(set(ids)):
        raise HTTPException(422, "ステップIDが重複しています")


@app.get("/api/health")
def health():
    return {"status": "ok"}


@app.get("/api/config")
def config():
    return {"mock_llm": settings.mock_llm, "auth_enabled": settings.auth_enabled,
            "provider": settings.llm_provider, "deployment": llm.model_label()}


@app.post("/api/asis", response_model=AsIsResponse)
def create_asis(inp: FlowInput, user: str = Depends(current_user)):
    try:
        res = llm.generate_asis(inp)
    except Exception as e:  # noqa: BLE001
        raise HTTPException(502, f"AS-IS生成に失敗しました: {e}") from e
    return AsIsResponse(result=res, mermaid=render.to_mermaid(res.flow))


@app.post("/api/tobe", response_model=ToBeResponse)
def create_tobe(req: ToBeRequest, user: str = Depends(current_user)):
    _validate_flow(req.asis)
    try:
        res = llm.generate_tobe(req.input, req.asis)
    except Exception as e:  # noqa: BLE001
        raise HTTPException(502, f"TO-BE生成に失敗しました: {e}") from e
    return ToBeResponse(
        result=res, mermaid=render.to_mermaid(res.flow), comparison=render.compare(req.asis, res.flow)
    )


@app.post("/api/render/mermaid")
def render_mermaid(req: RenderRequest, user: str = Depends(current_user)):
    _validate_flow(req.flow)
    return {"mermaid": render.to_mermaid(req.flow)}


@app.post("/api/render/drawio")
def render_drawio(req: RenderRequest, user: str = Depends(current_user)):
    _validate_flow(req.flow)
    xml = render.to_drawio(req.flow, req.title)
    return Response(
        xml, media_type="application/xml",
        headers={"Content-Disposition": 'attachment; filename="flow.drawio"'},
    )


class CompareRequest(BaseModel):
    asis: Flow
    tobe: Flow


@app.post("/api/compare", response_model=render.Comparison)
def compare(req: CompareRequest, user: str = Depends(current_user)):
    return render.compare(req.asis, req.tobe)


# ---------- 履歴 ----------
@app.get("/api/projects", response_model=list[Project])
def list_projects(user: str = Depends(current_user)):
    return store.list(user)


@app.get("/api/projects/{pid}", response_model=Project)
def get_project(pid: str, user: str = Depends(current_user)):
    p = store.get(pid, user)
    if not p:
        raise HTTPException(404, "見つかりません")
    return p


@app.post("/api/projects", response_model=Project)
def save_project(req: SaveRequest, user: str = Depends(current_user)):
    now = datetime.now(timezone.utc).isoformat()
    existing = store.get(req.id, user) if req.id else None
    p = Project(
        id=existing.id if existing else str(uuid.uuid4()),
        owner=user,
        created_at=existing.created_at if existing else now,
        updated_at=now,
        input=req.input, asis=req.asis, tobe=req.tobe,
    )
    return store.save(p)


@app.delete("/api/projects/{pid}")
def delete_project(pid: str, user: str = Depends(current_user)):
    if not store.delete(pid, user):
        raise HTTPException(404, "見つかりません")
    return {"deleted": pid}


# ---------- フロントエンド配信（ビルド済みReactを同一App Serviceで配信）----------
_static = Path(__file__).resolve().parent.parent / "static"
if _static.exists():
    app.mount("/assets", StaticFiles(directory=_static / "assets"), name="assets")

    @app.get("/{full_path:path}", include_in_schema=False)
    def spa(full_path: str):
        f = _static / full_path
        if full_path and f.is_file():
            return FileResponse(f)
        return FileResponse(_static / "index.html")
