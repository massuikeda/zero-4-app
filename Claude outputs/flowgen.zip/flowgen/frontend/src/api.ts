import { getToken } from "./auth";
import type { AsIsResult, Comparison, Flow, FlowInput, Project, ToBeResult } from "./types";

async function call<T>(path: string, body?: unknown, method?: string): Promise<T> {
  const token = await getToken();
  const res = await fetch(path, {
    method: method ?? (body === undefined ? "GET" : "POST"),
    headers: {
      ...(body !== undefined ? { "Content-Type": "application/json" } : {}),
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  if (!res.ok) {
    let msg = `${res.status}`;
    try {
      const j = await res.json();
      msg = typeof j.detail === "string" ? j.detail : JSON.stringify(j.detail);
    } catch {
      /* noop */
    }
    throw new Error(msg);
  }
  const ct = res.headers.get("content-type") ?? "";
  return (ct.includes("json") ? res.json() : res.text()) as Promise<T>;
}

export const api = {
  config: () => call<{ mock_llm: boolean; auth_enabled: boolean; deployment: string }>("/api/config"),
  asis: (input: FlowInput) => call<{ result: AsIsResult; mermaid: string }>("/api/asis", input),
  tobe: (input: FlowInput, asis: Flow) =>
    call<{ result: ToBeResult; mermaid: string; comparison: Comparison }>("/api/tobe", { input, asis }),
  mermaid: (flow: Flow) => call<{ mermaid: string }>("/api/render/mermaid", { flow }).then((r) => r.mermaid),
  drawio: (flow: Flow, title: string) => call<string>("/api/render/drawio", { flow, title }),
  compare: (asis: Flow, tobe: Flow) => call<Comparison>("/api/compare", { asis, tobe }),
  listProjects: () => call<Project[]>("/api/projects"),
  getProject: (id: string) => call<Project>(`/api/projects/${id}`),
  saveProject: (p: { id?: string; input: FlowInput; asis: AsIsResult | null; tobe: ToBeResult | null }) =>
    call<Project>("/api/projects", p),
  deleteProject: (id: string) => call<unknown>(`/api/projects/${id}`, undefined, "DELETE"),
};

export function download(filename: string, content: string, type = "text/plain") {
  const blob = new Blob([content], { type: `${type};charset=utf-8` });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  a.click();
  URL.revokeObjectURL(a.href);
}
