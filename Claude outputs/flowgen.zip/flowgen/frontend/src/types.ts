export const STEP_TYPES = ["作業", "判断", "システム処理", "帳票", "待ち"] as const;
export const CHANGE_ACTIONS = ["排除", "統合", "入替", "簡素化", "自動化", "新規"] as const;
export type StepType = (typeof STEP_TYPES)[number];
export type ChangeAction = (typeof CHANGE_ACTIONS)[number];

export const CHANGE_COLORS: Record<ChangeAction, string> = {
  排除: "#9E9E9E",
  統合: "#7B1FA2",
  入替: "#F57C00",
  簡素化: "#0288D1",
  自動化: "#2E7D32",
  新規: "#C2185B",
};

export interface FlowInput {
  business_name: string;
  department: string;
  frequency: string;
  actors: string[];
  current_steps: string;
  tools: string;
  issues: string;
  goals: string;
  constraints: string;
}

export interface Step {
  id: string;
  lane: string;
  type: StepType;
  name: string;
  tool: string;
  minutes: number;
  issue: string | null;
  change: ChangeAction | null;
  next: string[];
  condition_labels: string[];
}

export interface Flow {
  lanes: string[];
  steps: Step[];
}

export interface Change {
  target_step_ids: string[];
  action: ChangeAction;
  title: string;
  description: string;
  reason: string;
  effect_minutes: number;
  difficulty: "低" | "中" | "高";
  priority: "高" | "中" | "低";
}

export interface AsIsResult {
  flow: Flow;
  summary: string;
}

export interface ToBeResult {
  flow: Flow;
  changes: Change[];
  summary: string;
}

export interface Comparison {
  asis_steps: number;
  tobe_steps: number;
  asis_minutes: number;
  tobe_minutes: number;
  asis_handoffs: number;
  tobe_handoffs: number;
  asis_issues: number;
  reduction_rate: number;
}

export interface Project {
  id: string;
  owner: string;
  created_at: string;
  updated_at: string;
  input: FlowInput;
  asis: AsIsResult | null;
  tobe: ToBeResult | null;
}

export const EMPTY_INPUT: FlowInput = {
  business_name: "",
  department: "",
  frequency: "",
  actors: [],
  current_steps: "",
  tools: "",
  issues: "",
  goals: "",
  constraints: "",
};

export const SAMPLE_INPUT: FlowInput = {
  business_name: "請求書発行業務",
  department: "経理部",
  frequency: "月200件",
  actors: ["営業", "経理", "上長"],
  current_steps:
    "1. 営業が受注内容をExcelにまとめて経理へメール送付\n2. 経理がExcelの内容を会計システムに手入力\n3. 経理が請求書をPDF出力して印刷\n4. 上長が請求書を確認・承認（不備があれば経理へ差戻し）\n5. 承認待ち（平均1日）\n6. 経理が請求書を封入して郵送\n7. 経理が送付済みをExcel台帳に記録",
  tools: "Excel、Outlook、会計システム（勘定奉行）",
  issues: "Excelからの転記ミスが月10件程度ある。上長不在時に承認が止まる。郵送コストと手間がかかる。",
  goals: "請求書発行の工数を50%削減し、月末の残業をなくす",
  constraints: "会計システムは変更不可。新規ツール予算は年間100万円まで。Microsoft 365は利用可能。",
};
