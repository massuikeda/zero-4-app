import { useCallback, useEffect, useState } from "react";
import { api, download } from "./api";
import { AUTH_ENABLED, logout } from "./auth";
import { InputForm } from "./components/InputForm";
import { MermaidView } from "./components/MermaidView";
import { StepEditor } from "./components/StepEditor";
import { ChangeTable, ComparisonCards, Legend, changesToCsv } from "./components/ToBeReport";
import {
  EMPTY_INPUT,
  type AsIsResult,
  type Comparison,
  type Flow,
  type FlowInput,
  type Project,
  type ToBeResult,
} from "./types";

type Stage = 1 | 2 | 3;

function useMermaid(flow: Flow | undefined) {
  const [code, setCode] = useState("");
  useEffect(() => {
    if (!flow) return setCode("");
    const t = setTimeout(() => {
      api.mermaid(flow).then(setCode).catch(() => undefined);
    }, 400);
    return () => clearTimeout(t);
  }, [flow]);
  return code;
}

export default function App() {
  const [cfg, setCfg] = useState<{ mock_llm: boolean; deployment: string } | null>(null);
  const [stage, setStage] = useState<Stage>(1);
  const [input, setInput] = useState<FlowInput>(EMPTY_INPUT);
  const [asis, setAsis] = useState<AsIsResult | null>(null);
  const [tobe, setTobe] = useState<ToBeResult | null>(null);
  const [cmp, setCmp] = useState<Comparison | null>(null);
  const [projectId, setProjectId] = useState<string | undefined>();
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [editTobe, setEditTobe] = useState(false);
  const [formKey, setFormKey] = useState(0);

  const asisCode = useMermaid(asis?.flow);
  const tobeCode = useMermaid(tobe?.flow);

  const refreshProjects = useCallback(() => api.listProjects().then(setProjects).catch(() => undefined), []);
  useEffect(() => {
    api.config().then(setCfg).catch((e) => setError(`APIに接続できません: ${e.message}`));
    refreshProjects();
  }, [refreshProjects]);

  // TO-BE編集時に比較を再計算
  useEffect(() => {
    if (!asis || !tobe) return;
    const t = setTimeout(() => api.compare(asis.flow, tobe.flow).then(setCmp).catch(() => undefined), 400);
    return () => clearTimeout(t);
  }, [asis, tobe]);

  const run = async (label: string, fn: () => Promise<void>) => {
    setLoading(label);
    setError(null);
    try {
      await fn();
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setLoading(null);
    }
  };

  const save = async (a = asis, t = tobe) => {
    const p = await api.saveProject({ id: projectId, input, asis: a, tobe: t });
    setProjectId(p.id);
    refreshProjects();
  };

  const genAsis = () =>
    run("asis", async () => {
      const r = await api.asis(input);
      setAsis(r.result);
      setTobe(null);
      setCmp(null);
      setStage(2);
      await save(r.result, null);
    });

  const genTobe = () =>
    run("tobe", async () => {
      if (!asis) return;
      const r = await api.tobe(input, asis.flow);
      setTobe(r.result);
      setCmp(r.comparison);
      setStage(3);
      await save(asis, r.result);
    });

  const exportDrawio = (flow: Flow, suffix: string) =>
    run("export", async () => {
      const xml = await api.drawio(flow, `${input.business_name} ${suffix}`);
      download(`${input.business_name || "flow"}_${suffix}.drawio`, xml, "application/xml");
    });

  const open = (id: string) =>
    run("open", async () => {
      const p = await api.getProject(id);
      setProjectId(p.id);
      setInput(p.input);
      setFormKey((k) => k + 1);
      setAsis(p.asis);
      setTobe(p.tobe);
      setCmp(null);
      setStage(p.tobe ? 3 : p.asis ? 2 : 1);
    });

  const reset = () => {
    setProjectId(undefined);
    setInput(EMPTY_INPUT);
    setFormKey((k) => k + 1);
    setAsis(null);
    setTobe(null);
    setCmp(null);
    setStage(1);
  };

  return (
    <div className="app">
      <header>
        <div className="brand">
          <span className="logo">⇄</span> FlowGen <small>AS-IS / TO-BE 業務フロー自動作成</small>
        </div>
        <div className="header-right">
          {cfg && (
            <span className={`badge ${cfg.mock_llm ? "warn" : "ok"}`}>
              {cfg.mock_llm ? "モックモード（LLM未接続）" : cfg.deployment}
            </span>
          )}
          {AUTH_ENABLED && (
            <button className="ghost" onClick={logout}>
              ログアウト
            </button>
          )}
        </div>
      </header>

      <div className="layout">
        <aside>
          <button className="primary block" onClick={reset}>
            ＋ 新規作成
          </button>
          <h3>履歴</h3>
          <ul className="history">
            {projects.map((p) => (
              <li key={p.id} className={p.id === projectId ? "active" : ""}>
                <button onClick={() => open(p.id)}>
                  <span>{p.input.business_name || "(無題)"}</span>
                  <small>
                    {new Date(p.updated_at).toLocaleString("ja-JP")}　{p.tobe ? "TO-BE済" : p.asis ? "AS-IS済" : ""}
                  </small>
                </button>
                <button
                  className="icon"
                  title="削除"
                  onClick={() =>
                    confirm("削除しますか？") &&
                    api.deleteProject(p.id).then(() => {
                      if (p.id === projectId) reset();
                      refreshProjects();
                    })
                  }
                >
                  ×
                </button>
              </li>
            ))}
            {projects.length === 0 && <li className="empty">まだありません</li>}
          </ul>
        </aside>

        <main>
          <nav className="stepper">
            {(["入力", "AS-IS確認・修正", "TO-BE・改善案"] as const).map((l, i) => {
              const s = (i + 1) as Stage;
              const enabled = s === 1 || (s === 2 && asis) || (s === 3 && tobe);
              return (
                <button key={l} disabled={!enabled} className={stage === s ? "on" : ""} onClick={() => setStage(s)}>
                  <b>{s}</b> {l}
                </button>
              );
            })}
          </nav>

          {error && <div className="alert">⚠ {error}</div>}

          {stage === 1 && (
            <InputForm key={formKey} value={input} onChange={setInput} onSubmit={genAsis} loading={loading === "asis"} />
          )}

          {stage === 2 && asis && (
            <section className="card">
              <div className="card-head">
                <h2>2. AS-IS業務フローの確認・修正</h2>
                <div className="btns">
                  <button className="ghost" onClick={() => exportDrawio(asis.flow, "AS-IS")}>draw.io出力</button>
                  <button className="ghost" onClick={() => download("asis.mmd", asisCode)}>Mermaid出力</button>
                  <button className="ghost" onClick={() => run("save", () => save())}>保存</button>
                </div>
              </div>
              <p className="summary">{asis.summary}</p>
              <Legend />
              <MermaidView code={asisCode} />
              <h3>ステップを修正（図に即時反映）</h3>
              <StepEditor flow={asis.flow} onChange={(flow) => setAsis({ ...asis, flow })} />
              <div className="actions">
                <button className="ghost" onClick={() => setStage(1)}>← 入力に戻る</button>
                <button className="primary" onClick={genTobe} disabled={loading === "tobe"}>
                  {loading === "tobe" ? "TO-BEを作成中…" : "この内容でTO-BEを作成 →"}
                </button>
              </div>
            </section>
          )}

          {stage === 3 && asis && tobe && (
            <section className="card">
              <div className="card-head">
                <h2>3. TO-BE業務フローと改善案</h2>
                <div className="btns">
                  <button className="ghost" onClick={() => exportDrawio(tobe.flow, "TO-BE")}>TO-BE draw.io</button>
                  <button className="ghost" onClick={() => exportDrawio(asis.flow, "AS-IS")}>AS-IS draw.io</button>
                  <button className="ghost" onClick={() => download("改善施策.csv", changesToCsv(tobe.changes), "text/csv")}>
                    施策CSV
                  </button>
                  <button
                    className="ghost"
                    onClick={() =>
                      download("flow.json", JSON.stringify({ input, asis, tobe, comparison: cmp }, null, 2), "application/json")
                    }
                  >
                    JSON
                  </button>
                  <button className="ghost" onClick={() => run("save", () => save())}>保存</button>
                </div>
              </div>
              <p className="summary">{tobe.summary}</p>
              {cmp && <ComparisonCards c={cmp} />}

              <h3>改善施策一覧</h3>
              <ChangeTable changes={tobe.changes} />

              <Legend />
              <div className="compare-grid">
                <div>
                  <h3 className="lane-title asis">AS-IS（現状）</h3>
                  <MermaidView code={asisCode} />
                </div>
                <div>
                  <h3 className="lane-title tobe">TO-BE（あるべき姿）</h3>
                  <MermaidView code={tobeCode} />
                </div>
              </div>

              <button className="ghost" onClick={() => setEditTobe((v) => !v)}>
                {editTobe ? "▲ TO-BEの編集を閉じる" : "▼ TO-BEのステップを編集"}
              </button>
              {editTobe && <StepEditor flow={tobe.flow} showChange onChange={(flow) => setTobe({ ...tobe, flow })} />}

              <div className="actions">
                <button className="ghost" onClick={() => setStage(2)}>← AS-ISに戻る</button>
                <button className="ghost" onClick={genTobe} disabled={loading === "tobe"}>
                  {loading === "tobe" ? "再作成中…" : "TO-BEを再作成"}
                </button>
              </div>
            </section>
          )}
        </main>
      </div>
    </div>
  );
}
