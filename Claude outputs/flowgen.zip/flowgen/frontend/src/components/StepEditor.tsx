import { CHANGE_ACTIONS, STEP_TYPES, type ChangeAction, type Flow, type Step, type StepType } from "../types";

interface Props {
  flow: Flow;
  onChange: (f: Flow) => void;
  showChange?: boolean;
}

const split = (s: string) => s.split(/[,、\s]+/).map((x) => x.trim()).filter(Boolean);

export function StepEditor({ flow, onChange, showChange }: Props) {
  const update = (i: number, patch: Partial<Step>) => {
    const steps = flow.steps.map((s, j) => (j === i ? { ...s, ...patch } : s));
    onChange({ ...flow, steps });
  };
  const remove = (i: number) => {
    const removed = flow.steps[i].id;
    const steps = flow.steps
      .filter((_, j) => j !== i)
      .map((s) => {
        const keep = s.next.map((n, k) => [n, s.condition_labels[k] ?? ""] as const).filter(([n]) => n !== removed);
        return { ...s, next: keep.map(([n]) => n), condition_labels: s.condition_labels.length ? keep.map(([, l]) => l) : [] };
      });
    onChange({ ...flow, steps });
  };
  const add = () => {
    const nums = flow.steps.map((s) => parseInt(s.id.replace(/\D/g, ""), 10) || 0);
    const id = `S${String(Math.max(0, ...nums) + 1).padStart(2, "0")}`;
    const last = flow.steps[flow.steps.length - 1];
    const steps = flow.steps.map((s) => (s === last && s.next.length === 0 ? { ...s, next: [id] } : s));
    steps.push({
      id, lane: flow.lanes[0] ?? "担当者", type: "作業", name: "新しいステップ", tool: "",
      minutes: 10, issue: null, change: showChange ? "新規" : null, next: [], condition_labels: [],
    });
    onChange({ ...flow, steps });
  };

  return (
    <div className="editor">
      <div className="lanes-edit">
        <span>スイムレーン：</span>
        <input
          value={flow.lanes.join("、")}
          onChange={(e) => onChange({ ...flow, lanes: split(e.target.value) })}
        />
      </div>
      <div className="table-wrap">
        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>担当</th>
              <th>種別</th>
              <th>ステップ名</th>
              <th>分</th>
              <th>課題</th>
              {showChange && <th>変更</th>}
              <th>次（ID）</th>
              <th>分岐ラベル</th>
              <th />
            </tr>
          </thead>
          <tbody>
            {flow.steps.map((s, i) => (
              <tr key={s.id} className={s.issue ? "has-issue" : ""}>
                <td className="mono">{s.id}</td>
                <td>
                  <select value={s.lane} onChange={(e) => update(i, { lane: e.target.value })}>
                    {[...new Set([...flow.lanes, s.lane])].map((l) => (
                      <option key={l}>{l}</option>
                    ))}
                  </select>
                </td>
                <td>
                  <select value={s.type} onChange={(e) => update(i, { type: e.target.value as StepType })}>
                    {STEP_TYPES.map((t) => (
                      <option key={t}>{t}</option>
                    ))}
                  </select>
                </td>
                <td>
                  <input className="w-name" value={s.name} onChange={(e) => update(i, { name: e.target.value })} />
                </td>
                <td>
                  <input
                    className="w-num"
                    type="number"
                    min={0}
                    value={s.minutes}
                    onChange={(e) => update(i, { minutes: Number(e.target.value) || 0 })}
                  />
                </td>
                <td>
                  <input
                    className="w-issue"
                    value={s.issue ?? ""}
                    placeholder="なし"
                    onChange={(e) => update(i, { issue: e.target.value || null })}
                  />
                </td>
                {showChange && (
                  <td>
                    <select
                      value={s.change ?? ""}
                      onChange={(e) => update(i, { change: (e.target.value || null) as ChangeAction | null })}
                    >
                      <option value="">変更なし</option>
                      {CHANGE_ACTIONS.map((a) => (
                        <option key={a}>{a}</option>
                      ))}
                    </select>
                  </td>
                )}
                <td>
                  <input className="w-ids" value={s.next.join(",")} onChange={(e) => update(i, { next: split(e.target.value) })} />
                </td>
                <td>
                  <input
                    className="w-ids"
                    value={s.condition_labels.join(",")}
                    placeholder={s.type === "判断" ? "OK,差戻し" : ""}
                    onChange={(e) => update(i, { condition_labels: split(e.target.value) })}
                  />
                </td>
                <td>
                  <button className="icon" title="削除" onClick={() => remove(i)}>
                    ×
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <button className="ghost" onClick={add}>
        ＋ ステップを追加
      </button>
    </div>
  );
}
