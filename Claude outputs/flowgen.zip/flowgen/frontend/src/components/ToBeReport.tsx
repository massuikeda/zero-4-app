import { CHANGE_COLORS, type Change, type Comparison } from "../types";

export function ComparisonCards({ c }: { c: Comparison }) {
  const items = [
    { label: "ステップ数", a: c.asis_steps, b: c.tobe_steps, unit: "" },
    { label: "1回あたり工数", a: c.asis_minutes, b: c.tobe_minutes, unit: "分" },
    { label: "部署間の受け渡し", a: c.asis_handoffs, b: c.tobe_handoffs, unit: "回" },
  ];
  return (
    <div className="kpis">
      <div className="kpi highlight">
        <span className="kpi-label">工数削減率</span>
        <span className="kpi-big">{c.reduction_rate}%</span>
      </div>
      {items.map((it) => (
        <div className="kpi" key={it.label}>
          <span className="kpi-label">{it.label}</span>
          <span className="kpi-val">
            {it.a}
            {it.unit} <span className="arrow">→</span> <strong>{it.b}{it.unit}</strong>
          </span>
        </div>
      ))}
      <div className="kpi">
        <span className="kpi-label">AS-ISの課題箇所</span>
        <span className="kpi-val">{c.asis_issues}件</span>
      </div>
    </div>
  );
}

export function ChangeTable({ changes }: { changes: Change[] }) {
  const sorted = [...changes].sort((x, y) => "高中低".indexOf(x.priority) - "高中低".indexOf(y.priority));
  return (
    <div className="table-wrap">
      <table className="changes">
        <thead>
          <tr>
            <th>優先度</th>
            <th>区分</th>
            <th>施策</th>
            <th>内容</th>
            <th>理由</th>
            <th>対象</th>
            <th>効果/回</th>
            <th>難易度</th>
          </tr>
        </thead>
        <tbody>
          {sorted.map((c, i) => (
            <tr key={i}>
              <td><span className={`prio p${c.priority}`}>{c.priority}</span></td>
              <td>
                <span className="tag" style={{ borderColor: CHANGE_COLORS[c.action], color: CHANGE_COLORS[c.action] }}>
                  {c.action}
                </span>
              </td>
              <td className="strong">{c.title}</td>
              <td>{c.description}</td>
              <td className="muted">{c.reason}</td>
              <td className="mono">{c.target_step_ids.join(", ")}</td>
              <td className="mono">{c.effect_minutes}分</td>
              <td>{c.difficulty}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export function Legend() {
  return (
    <div className="legend">
      <span><i style={{ borderColor: "#D32F2F", background: "#FFEBEE" }} />課題あり</span>
      {Object.entries(CHANGE_COLORS).map(([k, v]) => (
        <span key={k}><i style={{ borderColor: v, background: `${v}22` }} />{k}</span>
      ))}
      <span className="shapes">□作業　◇判断　▭▭システム処理　▱帳票　◯待ち</span>
    </div>
  );
}

export function changesToCsv(changes: Change[]): string {
  const head = ["優先度", "区分", "施策", "内容", "理由", "対象ステップ", "効果(分/回)", "難易度"];
  const esc = (v: string | number) => `"${String(v).replace(/"/g, '""')}"`;
  const rows = changes.map((c) =>
    [c.priority, c.action, c.title, c.description, c.reason, c.target_step_ids.join(" "), c.effect_minutes, c.difficulty]
      .map(esc)
      .join(","),
  );
  return "﻿" + [head.map(esc).join(","), ...rows].join("\r\n");
}
