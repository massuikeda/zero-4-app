import { useState } from "react";
import { SAMPLE_INPUT, type FlowInput } from "../types";

interface Props {
  value: FlowInput;
  onChange: (v: FlowInput) => void;
  onSubmit: () => void;
  loading: boolean;
}

export function InputForm({ value, onChange, onSubmit, loading }: Props) {
  const [actorsText, setActorsText] = useState(value.actors.join("、"));
  const set = <K extends keyof FlowInput>(k: K, v: FlowInput[K]) => onChange({ ...value, [k]: v });
  const valid = value.business_name.trim() && value.current_steps.trim();

  return (
    <form
      className="card form"
      onSubmit={(e) => {
        e.preventDefault();
        if (valid) onSubmit();
      }}
    >
      <div className="card-head">
        <h2>1. 業務情報を入力</h2>
        <button
          type="button"
          className="ghost"
          onClick={() => {
            onChange(SAMPLE_INPUT);
            setActorsText(SAMPLE_INPUT.actors.join("、"));
          }}
        >
          サンプルを入れる
        </button>
      </div>

      <fieldset>
        <legend>基本情報</legend>
        <div className="grid3">
          <label>
            業務名 <em>必須</em>
            <input value={value.business_name} onChange={(e) => set("business_name", e.target.value)} placeholder="例：請求書発行業務" />
          </label>
          <label>
            対象部署
            <input value={value.department} onChange={(e) => set("department", e.target.value)} placeholder="例：経理部" />
          </label>
          <label>
            実施頻度
            <input value={value.frequency} onChange={(e) => set("frequency", e.target.value)} placeholder="例：月200件" />
          </label>
        </div>
        <label>
          登場人物・部署（スイムレーンになります。「、」区切り）
          <input
            value={actorsText}
            onChange={(e) => {
              setActorsText(e.target.value);
              set("actors", e.target.value.split(/[、,，\s]+/).filter(Boolean));
            }}
            placeholder="例：営業、経理、上長"
          />
        </label>
        <label>
          使用ツール・システム
          <input value={value.tools} onChange={(e) => set("tools", e.target.value)} placeholder="例：Excel、Outlook、会計システム" />
        </label>
      </fieldset>

      <fieldset>
        <legend>現状（AS-IS）</legend>
        <label>
          現状の手順 <em>必須</em>　<small>「誰が・何を・何で」を1行ずつ</small>
          <textarea rows={8} value={value.current_steps} onChange={(e) => set("current_steps", e.target.value)} placeholder={"1. 営業が受注内容をExcelで経理にメール送付\n2. 経理が会計システムに手入力\n..."} />
        </label>
        <label>
          現状の課題
          <textarea rows={3} value={value.issues} onChange={(e) => set("issues", e.target.value)} placeholder="例：転記ミスが多い、承認待ちで遅れる" />
        </label>
      </fieldset>

      <fieldset>
        <legend>改善方針（TO-BE）</legend>
        <div className="grid2">
          <label>
            目標
            <textarea rows={3} value={value.goals} onChange={(e) => set("goals", e.target.value)} placeholder="例：工数50%削減" />
          </label>
          <label>
            制約
            <textarea rows={3} value={value.constraints} onChange={(e) => set("constraints", e.target.value)} placeholder="例：会計システムは変更不可、予算100万円" />
          </label>
        </div>
      </fieldset>

      <div className="actions">
        <button type="submit" className="primary" disabled={!valid || loading}>
          {loading ? "AS-ISを作成中…" : "AS-ISフローを作成 →"}
        </button>
      </div>
    </form>
  );
}
