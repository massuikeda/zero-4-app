import mermaid from "mermaid";
import { useEffect, useId, useRef, useState } from "react";

mermaid.initialize({
  startOnLoad: false,
  securityLevel: "strict",
  theme: "neutral",
  flowchart: { htmlLabels: true, curve: "basis" },
});

export function MermaidView({ code }: { code: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const id = useId().replace(/:/g, "");
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    if (!code) return;
    mermaid
      .render(`m${id}${Date.now()}`, code)
      .then(({ svg }) => {
        if (!cancelled && ref.current) {
          ref.current.innerHTML = svg;
          setErr(null);
        }
      })
      .catch((e) => !cancelled && setErr(String(e)));
    return () => {
      cancelled = true;
    };
  }, [code, id]);

  return (
    <div className="diagram">
      {err && <pre className="error">図の描画に失敗しました: {err}</pre>}
      <div ref={ref} />
    </div>
  );
}

export function svgOf(container: HTMLElement | null): string | null {
  const svg = container?.querySelector("svg");
  return svg ? new XMLSerializer().serializeToString(svg) : null;
}
