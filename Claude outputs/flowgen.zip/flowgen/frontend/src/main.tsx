import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import { AUTH_ENABLED, initAuth } from "./auth";
import "./styles.css";

const root = ReactDOM.createRoot(document.getElementById("root")!);

initAuth()
  .then((account) => {
    if (AUTH_ENABLED && !account) return; // ログイン画面へリダイレクト中
    root.render(
      <React.StrictMode>
        <App />
      </React.StrictMode>,
    );
  })
  .catch((e) => root.render(<pre style={{ padding: 24 }}>認証エラー: {String(e)}</pre>));
