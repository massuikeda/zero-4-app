import {
  InteractionRequiredAuthError,
  PublicClientApplication,
  type AccountInfo,
} from "@azure/msal-browser";

const env = import.meta.env;
export const AUTH_ENABLED = env.VITE_AUTH_ENABLED === "true";
const SCOPE = env.VITE_ENTRA_API_SCOPE as string;

let msal: PublicClientApplication | null = null;

export async function initAuth(): Promise<AccountInfo | null> {
  if (!AUTH_ENABLED) return null;
  msal = new PublicClientApplication({
    auth: {
      clientId: env.VITE_ENTRA_SPA_CLIENT_ID,
      authority: `https://login.microsoftonline.com/${env.VITE_ENTRA_TENANT_ID}`,
      redirectUri: window.location.origin,
    },
    cache: { cacheLocation: "sessionStorage" },
  });
  await msal.initialize();
  const res = await msal.handleRedirectPromise();
  if (res?.account) msal.setActiveAccount(res.account);
  const account = msal.getActiveAccount() ?? msal.getAllAccounts()[0] ?? null;
  if (!account) {
    await msal.loginRedirect({ scopes: [SCOPE] });
    return null;
  }
  msal.setActiveAccount(account);
  return account;
}

export async function getToken(): Promise<string | null> {
  if (!AUTH_ENABLED || !msal) return null;
  const account = msal.getActiveAccount();
  if (!account) return null;
  try {
    const r = await msal.acquireTokenSilent({ scopes: [SCOPE], account });
    return r.accessToken;
  } catch (e) {
    if (e instanceof InteractionRequiredAuthError) {
      await msal.acquireTokenRedirect({ scopes: [SCOPE] });
    }
    throw e;
  }
}

export function logout() {
  msal?.logoutRedirect();
}
