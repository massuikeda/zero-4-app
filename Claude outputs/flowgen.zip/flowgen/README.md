# FlowGen — AS-IS / TO-BE 業務フロー自動作成アプリ

業務情報を入力すると、Azure OpenAI が **固定スキーマのJSON** で AS-IS / TO-BE を構造化し、
アプリ側が **固定テンプレート** で図（Mermaid / draw.io）・比較表・改善施策一覧を生成します。
AIには図を描かせないため、誰が使っても同じ型の成果物になります。

```
入力フォーム → Azure OpenAI①(AS-IS構造化) → 人が確認・修正 → Azure OpenAI②(TO-BE+施策)
            → 固定テンプレート描画（スイムレーン図 / 比較KPI / 施策表）→ draw.io・CSV・JSON出力
```

## 構成

| 層 | 技術 |
|---|---|
| フロント | React + TypeScript + Vite、Mermaid（表示）、MSAL（Entra ID） |
| バックエンド | Python FastAPI、Azure OpenAI（Structured Outputs）、PyJWT |
| 基盤 | Azure App Service（Linux / Python）1台でAPIと画面を配信 |
| 保存 | Azure Cosmos DB（未設定ならローカルJSON） |
| 認証 | Entra ID（SPAアプリ + APIアプリの2つを登録） |

```
flowgen/
├─ backend/
│  ├─ app/
│  │  ├─ schemas.py   … 業務フローの「固定の型」（ここを変えると型が変わる）
│  │  ├─ prompts.py   … AS-IS / TO-BE 用プロンプト（ECRSの改善ルール）
│  │  ├─ llm.py       … Azure OpenAI 呼び出し（キー or マネージドID）
│  │  ├─ mock.py      … Azure OpenAI未接続時のモック
│  │  ├─ render.py    … Mermaid / draw.io / 比較指標の生成（固定テンプレート）
│  │  ├─ storage.py   … Cosmos DB / ローカルJSON
│  │  ├─ auth.py      … Entra ID トークン検証
│  │  └─ main.py      … API ルーティング、ビルド済み画面の配信
│  ├─ requirements.txt
│  └─ .env.example
└─ frontend/
   ├─ src/ (App.tsx, components/, api.ts, auth.ts, types.ts)
   └─ .env.example
```

### 固定の型（schemas.py）

- ステップ種別：**作業 / 判断 / システム処理 / 帳票 / 待ち**（図形が固定で対応）
- TO-BE変更区分：**排除 / 統合 / 入替 / 簡素化 / 自動化 / 新規**（ECRS＋α、色が固定で対応）
- 各ステップ：ID・担当レーン・名称・ツール・所要分・課題・変更区分・遷移先・分岐ラベル
- 施策：対象ステップ・区分・内容・理由・削減分数・難易度・優先度

## ローカルで動かす

```bash
# バックエンド（Azure OpenAI未設定ならモックモードで起動）
cd backend
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env      # Azure OpenAI を使う場合は ENDPOINT 等を記入
uvicorn app.main:app --reload --port 8000

# フロントエンド（別ターミナル）
cd frontend
npm install
npm run dev               # http://localhost:5173
```

画面の「サンプルを入れる」→「AS-ISフローを作成」で一通り試せます。

## 使うLLMの切り替え

`backend/.env` の `LLM_PROVIDER` で切り替えます。プロンプトと型は共通なので、どれを使っても同じ形式の結果が出ます。

| LLM_PROVIDER | 用途 | 必要な設定 |
|---|---|---|
| `claude` | Azure OpenAIが使えない間の代替・検証 | `ANTHROPIC_API_KEY`, `CLAUDE_MODEL` |
| `foundry` | Azure契約の中でClaudeを使う | `ANTHROPIC_FOUNDRY_RESOURCE`, `CLAUDE_MODEL`（デプロイ名）, キー or `az login` |
| `azure_openai` | 本番想定 | `AZURE_OPENAI_ENDPOINT`, `AZURE_OPENAI_DEPLOYMENT`, キー or `az login` |
| `mock` | LLMなしで画面だけ確認 | なし |

注意：Claude APIを使う場合、入力した業務内容はAnthropicのAPIに送られます。社内の機密情報を入れる前に、自社のルールで使ってよいか確認してください。

## API

| メソッド | パス | 内容 |
|---|---|---|
| POST | /api/asis | 入力 → AS-IS（JSON＋Mermaid） |
| POST | /api/tobe | 入力＋AS-IS → TO-BE・施策・比較 |
| POST | /api/render/mermaid | フロー → Mermaid |
| POST | /api/render/drawio | フロー → .drawio ファイル |
| POST | /api/compare | AS-IS / TO-BE の比較指標 |
| GET/POST/DELETE | /api/projects | 履歴の一覧・保存・削除 |

`http://localhost:8000/docs` で Swagger UI が開きます。

## Azure へのデプロイ

### 1. Azure OpenAI
1. Azure OpenAI リソースを作成し、`gpt-4o`（2024-08-06 以降。Structured Outputs対応）をデプロイ
2. デプロイ名を `AZURE_OPENAI_DEPLOYMENT` に設定
3. 閉域にする場合はプライベートエンドポイント＋App Service の VNet 統合

### 2. Entra ID（アプリ登録を2つ）
- **API用（flowgen-api）**
  - 「APIの公開」でアプリケーションID URI を `api://<API_CLIENT_ID>` に設定
  - スコープ `access_as_user` を追加
  - 「マニフェスト」で `accessTokenAcceptedVersion` を `2` に
- **SPA用（flowgen-spa）**
  - プラットフォーム「シングルページアプリケーション」、リダイレクトURI に `https://<app>.azurewebsites.net`（開発時は `http://localhost:5173` も）
  - 「APIのアクセス許可」で flowgen-api の `access_as_user` を追加し、管理者の同意を付与

### 3. Cosmos DB
- NoSQL API のアカウントを作成（DB `flowgen` / コンテナ `projects` / パーティションキー `/owner` は起動時に自動作成）
- ※マネージドIDで使う場合、DB・コンテナは事前作成が必要（データプレーンRBACでは作成不可）

### 4. App Service
```bash
# フロントをビルド（backend/static に出力される）
cd frontend
cp .env.example .env.production   # VITE_AUTH_ENABLED=true と各IDを記入
npm ci && npm run build

# バックエンドごとデプロイ
cd ../backend
az webapp up --name <app-name> --resource-group <rg> --runtime "PYTHON:3.12" --sku B1
az webapp config set -n <app-name> -g <rg> \
  --startup-file "gunicorn -w 2 -k uvicorn.workers.UvicornWorker -b 0.0.0.0:8000 app.main:app --timeout 120"

# マネージドID を有効化し、権限を付与
az webapp identity assign -n <app-name> -g <rg>
PRINCIPAL=$(az webapp identity show -n <app-name> -g <rg> --query principalId -o tsv)
az role assignment create --assignee $PRINCIPAL --role "Cognitive Services OpenAI User" \
  --scope <Azure OpenAI リソースID>
az cosmosdb sql role assignment create -a <cosmos-account> -g <rg> \
  --role-definition-id 00000000-0000-0000-0000-000000000002 \
  --principal-id $PRINCIPAL --scope "/"

# アプリ設定（キーは空 → マネージドIDで認証）
az webapp config appsettings set -n <app-name> -g <rg> --settings \
  AZURE_OPENAI_ENDPOINT=https://<aoai>.openai.azure.com/ AZURE_OPENAI_DEPLOYMENT=gpt-4o \
  COSMOS_ENDPOINT=https://<cosmos>.documents.azure.com:443/ \
  AUTH_ENABLED=true ENTRA_TENANT_ID=<tenant> ENTRA_API_CLIENT_ID=<api-client-id> \
  CORS_ORIGINS=https://<app-name>.azurewebsites.net SCM_DO_BUILD_DURING_DEPLOYMENT=true
```

## カスタマイズのポイント

- **型を変えたい** → `schemas.py`（項目追加）と `render.py`（図形・色）を変更。フロントは `types.ts` を合わせる
- **改善の観点を社内ルールに合わせたい** → `prompts.py` の TOBE_SYSTEM にチェック観点を追記
- **出力形式を増やしたい** → `render.py` に関数を追加（Excel/PowerPoint化は openpyxl / python-pptx で同じJSONから生成可能）

## 今後の拡張候補

1. Excel・PowerPoint 出力（社内報告書テンプレートへの差し込み）
2. 改善効果の年間換算（頻度×削減分数×人件費単価）
3. 部署別テンプレート、過去フローの検索・再利用（Azure AI Search）
4. 生成ログとプロンプトのバージョン管理（Application Insights）
